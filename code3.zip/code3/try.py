import jieba
print(jieba.__version__)
import torch
print(torch.version.__version__)
import numpy
print(numpy.__version__)